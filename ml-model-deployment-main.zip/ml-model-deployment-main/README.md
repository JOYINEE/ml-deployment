Watch the Course on Skillshare  at https://skl.sh/34Wt5E3

In this course you will learn how to deploy Machine Learning Models using various techniques. You should have basic understanding of Python and Machine Learning before starting on this course. 

Course Structure:

1. Creating a Model
2. Saving a Model
3. Exporting the Model to another environment
4. Creating a REST API and using it locally
5. Creating a Machine Learning REST API on a Cloud virtual server
6. Creating a Serverless Machine Learning REST API using Cloud Functions
7. Deploying TensorFlow and Keras models using TensorFlow Serving
8. Deploying PyTorch Models
9. Creating REST API for Pytorch Models
